Dear researcher

This file contains our recorded data from three types of sensors for “Texture recognition based on multi-sensory integration of proprioceptive and tactile signals” paper.
6 Textures were manipulated 10 times with six speeds. 
Note: the .npz file can be opened with this code :
data = np.load(address)
data = data ['press']
The image of textures and additional information are in the paper.
Contact : rostamianbehnam@yahoo.com

Good luck
